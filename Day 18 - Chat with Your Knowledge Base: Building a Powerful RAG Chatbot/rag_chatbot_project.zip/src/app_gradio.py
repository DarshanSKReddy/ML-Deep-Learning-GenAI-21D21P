
import os
import gradio as gr
from rag import load_documents, build_vectorstore, load_llm, answer_query

DATA_PATH = "../data/reviews.csv"

docs, col = load_documents(DATA_PATH)
vectorstore = build_vectorstore(docs, db_type="faiss")
llm = load_llm("openai")

def chat_fn(message, history):
    answer, sources = answer_query(message, vectorstore, llm)
    return answer

demo = gr.ChatInterface(chat_fn, title="RAG Chatbot over reviews.csv")

if __name__ == "__main__":
    demo.launch()
