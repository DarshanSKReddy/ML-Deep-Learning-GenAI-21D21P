
import streamlit as st
from rag import load_documents, build_vectorstore, load_llm, answer_query

st.set_page_config(page_title="RAG Chatbot", layout="wide")

DATA_PATH = "../data/reviews.csv"

@st.cache_resource
def init():
    docs, col = load_documents(DATA_PATH)
    vs = build_vectorstore(docs, db_type="faiss")
    llm = load_llm("openai")
    return vs, llm

vectorstore, llm = init()

st.title("RAG Chatbot over reviews.csv")

query = st.text_input("Ask a question about the reviews:")

if query:
    answer, sources = answer_query(query, vectorstore, llm)
    st.subheader("Answer")
    st.write(answer)

    with st.expander("Sources"):
        for i, d in enumerate(sources, 1):
            st.write(f"Source {i}:")
            st.write(d.page_content[:500])
