# RAG Chatbot Project (reviews.csv)

This is a complete **Retrieval-Augmented Generation (RAG)** chatbot
project built over a CSV dataset (`reviews.csv`).

## Features

-   Uses **HuggingFace sentence-transformers** for embeddings
-   Supports **FAISS** or **Chroma** vector databases
-   Uses a **real LLM** (OpenAI via LangChain) for answers
-   Provides:
    -   **Gradio** web chat UI
    -   **Streamlit** web app UI
-   Clean, submission-ready project structure

## Project Structure

    rag_chatbot_project/
    │
    ├── data/
    │   └── reviews.csv
    ├── src/
    │   ├── rag.py              # Core RAG pipeline
    │   ├── app_gradio.py       # Gradio UI
    │   └── app_streamlit.py    # Streamlit UI
    ├── requirements.txt
    └── README.md

## Setup

1.  Create a virtual environment (optional but recommended)
2.  Install dependencies:

```{=html}
<!-- -->
```
    pip install -r requirements.txt

3.  Set your OpenAI API key:

```{=html}
<!-- -->
```
    export OPENAI_API_KEY=your_key_here

## Run Gradio App

    cd src
    python app_gradio.py

## Run Streamlit App

    cd src
    streamlit run app_streamlit.py

## Notes

-   You can switch between **FAISS** and **Chroma** in `rag.py`
-   You can replace OpenAI with Groq or HuggingFace models inside
    `load_llm()`
-   This project is suitable for **college submissions, internships, and
    demos**
