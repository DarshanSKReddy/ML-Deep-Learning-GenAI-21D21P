
import os
import pandas as pd
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS, Chroma
from langchain.schema import Document

# Optional LLMs
from langchain_openai import ChatOpenAI

def load_documents(csv_path: str, text_column: str = None):
    df = pd.read_csv(csv_path)
    if text_column is None:
        # pick first object column
        text_cols = [c for c in df.columns if df[c].dtype == 'object']
        if not text_cols:
            raise ValueError("No text column found in CSV")
        text_column = text_cols[0]
    texts = df[text_column].astype(str).tolist()
    docs = [Document(page_content=t) for t in texts]
    return docs, text_column

def build_vectorstore(docs, db_type="faiss", persist_dir="vector_db"):
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    split_docs = splitter.split_documents(docs)

    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

    if db_type.lower() == "faiss":
        vs = FAISS.from_documents(split_docs, embeddings)
    elif db_type.lower() == "chroma":
        vs = Chroma.from_documents(split_docs, embeddings, persist_directory=persist_dir)
        vs.persist()
    else:
        raise ValueError("db_type must be 'faiss' or 'chroma'")

    return vs

def load_llm(provider="openai"):
    # You can switch providers here
    if provider == "openai":
        # Requires: export OPENAI_API_KEY=...
        return ChatOpenAI(model="gpt-4o-mini", temperature=0.2)
    else:
        raise NotImplementedError("Add Groq or HF here if needed")

def answer_query(query, vectorstore, llm, k=4):
    docs = vectorstore.similarity_search(query, k=k)
    context = "\n\n".join([d.page_content for d in docs])

    prompt = f"""You are a helpful assistant. Use the context below to answer the question.

Context:
{context}

Question: {query}
Answer:"""

    response = llm.invoke(prompt)
    return response.content, docs
